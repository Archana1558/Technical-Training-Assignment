#include <stdio.h>
union Data {int i; float f;};
int main(){union Data d;d.i=10;printf("%d\n",d.i);d.f=5.5;printf("%f\n",d.f);printf("%d\n",d.i);return 0;}