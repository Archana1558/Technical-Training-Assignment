#include <stdio.h>
#include <stdlib.h>
int main(){int r=2,c=3;int **a=(int**)malloc(r*sizeof(int*));for(int i=0;i<r;i++)a[i]=(int*)malloc(c*sizeof(int));int k=1;for(int i=0;i<r;i++){for(int j=0;j<c;j++){a[i][j]=k++;printf("%d ",a[i][j]);}printf("\n");}return 0;}