#include <stdio.h>
int max(int a[],int n){int m=a[0];for(int i=1;i<n;i++)if(a[i]>m)m=a[i];return m;}
int main(){int a[]={3,7,2,9,5};printf("%d\n",max(a,5));return 0;}