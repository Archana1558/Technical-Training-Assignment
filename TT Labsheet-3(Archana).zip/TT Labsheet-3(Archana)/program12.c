#include <stdio.h>
#include <stdlib.h>
struct Book{char title[20];char author[20];float price;};
int main(){struct Book *b=malloc(5*sizeof(struct Book));for(int i=0;i<5;i++)scanf("%s%s%f",b[i].title,b[i].author,&b[i].price);for(int i=0;i<5;i++)printf("%s %s %.2f\n",b[i].title,b[i].author,b[i].price);return 0;}