#include <stdio.h>
struct Employee {int id; char name[20]; float salary;};
int main(){struct Employee e[3]={{1,"A",5000},{2,"B",6000},{3,"C",7000}};for(int i=0;i<3;i++)printf("%d %s %.2f\n",e[i].id,e[i].name,e[i].salary);return 0;}