#include <stdio.h>
#include <stdlib.h>
int main(){char *names[5];for(int i=0;i<5;i++){names[i]=malloc(20);scanf("%s",names[i]);}for(int i=0;i<5;i++)printf("%s\n",names[i]);return 0;}