#include <stdio.h>
void h1(){printf("Helper 1\n");}
void h2(){printf("Helper 2\n");}
void run(void(*f)()){f();}
int main(){run(h1);run(h2);return 0;}