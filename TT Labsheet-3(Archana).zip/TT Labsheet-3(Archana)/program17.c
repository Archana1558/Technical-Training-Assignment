#include <stdio.h>
int add(int a,int b){return a+b;}int sub(int a,int b){return a-b;}int mul(int a,int b){return a*b;}
int main(){int a=6,b=3;int(*op)(int,int);op=add;printf("%d\n",op(a,b));op=sub;printf("%d\n",op(a,b));op=mul;printf("%d\n",op(a,b));return 0;}