#include <stdio.h>
#include <string.h>
struct Student{char name[20];int marks;};
int main(){struct Student s[3]={{"A",80},{"B",95},{"C",85}};for(int i=0;i<3-1;i++)for(int j=i+1;j<3;j++)if(s[i].marks<s[j].marks){struct Student t=s[i];s[i]=s[j];s[j]=t;}for(int i=0;i<3;i++)printf("%s %d\n",s[i].name,s[i].marks);return 0;}