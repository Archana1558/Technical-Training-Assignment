#include <stdio.h>
struct Test{int val;void(*f)(int*);};
void mod(int *x){*x+=5;}
int main(){struct Test t={10,mod};t.f(&t.val);printf("%d\n",t.val);return 0;}