#include <stdio.h>
struct Data{int type;union{int i;float f;}u;};
int main(){struct Data d;d.type=0;d.u.i=10;printf("%d\n",d.u.i);d.type=1;d.u.f=5.5;printf("%f\n",d.u.f);return 0;}