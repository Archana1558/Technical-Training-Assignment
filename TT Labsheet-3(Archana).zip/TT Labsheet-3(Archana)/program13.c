#include <stdio.h>
int* largest(int a[],int n){int *m=&a[0];for(int i=1;i<n;i++)if(a[i]>*m)m=&a[i];return m;}
int main(){int a[]={3,9,7,2};int *p=largest(a,4);printf("%d\n",*p);return 0;}