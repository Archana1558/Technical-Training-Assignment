#include <stdio.h>
struct Car{char model[20];int year;float price;};
int main(){struct Car c={"BMW",2020,50000},*p=&c;p->year=2022;p->price=55000;printf("%s %d %.2f\n",p->model,p->year,p->price);return 0;}