#include <stdio.h>
void fact(int n,long *r){if(n==0||n==1){*r=1;return;}long t;fact(n-1,&t);*r=n*t;}
int main(){int n=5;long r;fact(n,&r);printf("%ld\n",r);return 0;}