#include <stdio.h>
int main(){int a=5,b=10,*p=&a,*q=&b,temp;temp=*p;*p=*q;*q=temp;printf("%d %d\n",a,b);return 0;}