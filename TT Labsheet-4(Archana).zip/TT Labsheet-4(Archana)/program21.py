name = "Alice"
age = 21
print(f"My name is {name} and I am {age} years old.")