s = "Python"
print(s[::-1])