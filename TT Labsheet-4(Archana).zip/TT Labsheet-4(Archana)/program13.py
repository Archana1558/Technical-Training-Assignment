numbers = [3, 1, 4]
numbers.append(5)
numbers.insert(1, 2)
numbers.remove(4)
numbers.sort()
print(numbers)